const slides = [
  {
    chapter: 'THE INTRO', kicker: 'MILO AI · WORKING REMOTELY FROM DENMARK', title: 'Yo, I’m Milo.', description: 'I do cool stuff with cool people and cool companies.', footer: 'A VERY SHORT INTRO',
    tags: ['FOUNDER', 'ADVISOR', 'OPERATOR']
  },
  {
    chapter: 'THE ENERGY', kicker: 'A GROWTH GUY, JUST NOT THE USUAL KIND', title: 'The “Unconventional Growth” Guy.', description: 'Less playbook. More curiosity, good people, and the occasional idea that probably should not work.', footer: 'NOT BUILT FOR THE STRAIGHT LINE'
  },
  {
    chapter: 'THE NUMBERS', kicker: 'A FEW MILESTONES ALONG THE WAY', title: 'Fifteen years of building.', description: 'I’ve been a founder for 15+ years. Here are a few numbers that followed.', footer: 'THE SHORT VERSION',
    metrics: [
      { target: 10, suffix: '+', label: 'BUSINESSES BUILT' },
      { target: 10000, suffix: '+', label: 'CUSTOMERS SERVED' },
      { target: 10000000, prefix: '$', suffix: '+', label: 'RAISED' },
      { target: 5, label: 'BUSINESSES SOLD' }
    ]
  },
  {
    chapter: 'FRACTIONAL', kicker: 'IN THE ROOM, NOT ON THE SIDELINES', title: 'A co-founder, when you need one.', description: 'For 8 years, I was a fractional co-founder, helping founders:', footer: '0 → 1 IS A GOOD PLACE TO START',
    lines: ['Go from 0 → 1', 'Raise millions', 'Scale from idea to exit']
  },
  {
    chapter: 'THE BEGINNING', kicker: 'ENTREPRENEURSHIP WAS IN THE DNA EARLY', title: 'It started at school.', description: 'Long before the pitch decks, there were tiny businesses and a stubborn instinct to try.', footer: 'A VERY EARLY START',
    lines: ['Ran a hair salon at school', 'Sold coffee at the hospital', 'Flipped second-hand road bikes']
  },
  {
    chapter: 'RECENTLY', kicker: 'HEAD OF GROWTH · RIFF.AI · 2025', title: 'Build, learn, turn the dial.', description: 'A year spent helping a small team make a bigger dent.', footer: 'RIFF.AI · 2025',
    lines: ['Grew revenue 500%', 'Closed a $16M Series A', 'Scaled the team from 5 → 20+', 'Led a pivot, rebrand & enterprise wins']
  },
  {
    chapter: 'THE TOOLKIT', kicker: 'THINGS I’M A LITTLE OBSESSED WITH', title: 'Make it happen in the real world.', description: 'The best growth rarely begins with another dashboard.', footer: 'I DOCUMENT EVERYTHING ON LINKEDIN',
    lines: ['Networking & storytelling', 'IRL experiments & stunts', 'Impossible missions'],
    link: { label: 'Find me on LinkedIn', href: 'https://www.linkedin.com/' }
  },
  {
    chapter: 'THE FUTURE', kicker: 'GOOD ROOMS, BETTER PEOPLE', title: 'Bring the interesting people together.', description: 'I host events for cool companies like:', footer: 'AND MANY MORE',
    lines: ['Nvidia · Qualcomm · Nebius · PostHog', 'ElevenLabs · n8n · Lovable · Cursor', 'Supabase · Shine']
  },
  {
    chapter: 'YOUR TURN', kicker: 'BRAND DEAL? ADVISORY? EVENTS?', title: 'Let’s work together.', description: 'Have a good, slightly unreasonable idea? I’d love to hear it. PS: I respond to every email.', footer: 'SHOULD WE GET TO WORK?',
    link: { label: 'Email hello@milo.gg', href: 'mailto:hello@milo.gg' }
  }
];

const $ = (selector, root = document) => root.querySelector(selector);
const storyCard = $('#story-card');
const cardCopy = $('#card-copy');
const currentNumber = $('#slide-current');
const progress = $('#deck-progress');
let currentSlide = 0;
let transitionTimer;

function renderSlide(index, animate = false) {
  currentSlide = (index + slides.length) % slides.length;
  const slide = slides[currentSlide];
  if (animate) {
    storyCard.closest('.card-stack').classList.add('changing');
    window.clearTimeout(transitionTimer);
    transitionTimer = window.setTimeout(() => {
      paintSlide(slide);
      storyCard.closest('.card-stack').classList.remove('changing');
    }, 155);
  } else {
    paintSlide(slide);
  }
  currentNumber.textContent = String(currentSlide + 1);
  $('#card-chapter').textContent = slide.chapter;
  $('#card-index-label').textContent = slide.footer;
  [...progress.children].forEach((dot, i) => {
    dot.classList.toggle('is-active', i === currentSlide);
    if (i === currentSlide) dot.setAttribute('aria-current', 'step');
    else dot.removeAttribute('aria-current');
  });
}

function paintSlide(slide) {
  cardCopy.replaceChildren();
  const kicker = document.createElement('p');
  kicker.className = 'card-kicker';
  kicker.textContent = slide.kicker;
  const title = document.createElement('h1');
  title.className = 'card-title';
  title.textContent = slide.title;
  const description = document.createElement('p');
  description.className = 'card-description';
  description.textContent = slide.description;
  cardCopy.append(kicker, title, description);

  if (slide.lines?.length) {
    const list = document.createElement('div');
    list.className = 'card-lines';
    for (const text of slide.lines) {
      const line = document.createElement('div');
      line.className = 'card-line';
      line.textContent = text;
      list.append(line);
    }
    cardCopy.append(list);
  }
  if (slide.metrics?.length) {
    const grid = document.createElement('div');
    grid.className = 'stats-grid';
    const counters = [];
    for (const metric of slide.metrics) {
      const tile = document.createElement('div');
      tile.className = 'stat-tile';
      const value = document.createElement('strong');
      value.className = 'stat-value';
      value.textContent = `${metric.prefix || ''}0${metric.suffix || ''}`;
      const label = document.createElement('span');
      label.className = 'stat-label';
      label.textContent = metric.label;
      tile.append(value, label);
      grid.append(tile);
      counters.push({ element: value, ...metric });
    }
    cardCopy.append(grid);
    const duration = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 780;
    const started = performance.now();
    const tick = (now) => {
      const progress = duration === 0 ? 1 : Math.min(1, (now - started) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      counters.forEach((counter) => {
        const number = Math.round(counter.target * eased).toLocaleString();
        counter.element.textContent = `${counter.prefix || ''}${number}${counter.suffix || ''}`;
      });
      if (progress < 1) window.requestAnimationFrame(tick);
    };
    window.requestAnimationFrame(tick);
  }
  if (slide.tags?.length) {
    const tags = document.createElement('div');
    tags.className = 'card-tags';
    for (const text of slide.tags) {
      const tag = document.createElement('span');
      tag.className = 'card-tag';
      tag.textContent = text;
      tags.append(tag);
    }
    cardCopy.append(tags);
  }
  if (slide.link) {
    const link = document.createElement('a');
    link.className = 'card-cta';
    link.href = slide.link.href;
    link.target = slide.link.href.startsWith('https:') ? '_blank' : '_self';
    if (link.target === '_blank') link.rel = 'noreferrer noopener';
    link.textContent = slide.link.label;
    const arrow = document.createElement('span');
    arrow.setAttribute('aria-hidden', 'true');
    arrow.textContent = '↗';
    link.append(arrow);
    cardCopy.append(link);
  }
}

for (let i = 0; i < slides.length; i++) {
  const dot = document.createElement('button');
  dot.type = 'button';
  dot.className = 'progress-dot';
  dot.setAttribute('aria-label', `Go to slide ${i + 1}`);
  dot.addEventListener('click', () => renderSlide(i, true));
  progress.append(dot);
}
$('#previous-card').addEventListener('click', () => renderSlide(currentSlide - 1, true));
$('#next-card').addEventListener('click', () => renderSlide(currentSlide + 1, true));
document.addEventListener('keydown', (event) => {
  if ($('#guestbook-modal').hidden === false) {
    if (event.key === 'Escape') closeGuestbook();
    return;
  }
  if (event.key === 'ArrowLeft') renderSlide(currentSlide - 1, true);
  if (event.key === 'ArrowRight') renderSlide(currentSlide + 1, true);
});
renderSlide(0);
$('#world').classList.add('is-loaded');

let pointerX = 0;
let pointerY = 0;
let pointerFrame = false;
const finePointer = window.matchMedia('(pointer: fine)').matches;
if (finePointer) {
  document.addEventListener('pointermove', (event) => {
    if (pointerFrame) return;
    pointerFrame = true;
    requestAnimationFrame(() => {
      const x = event.clientX / window.innerWidth - 0.5;
      const y = event.clientY / window.innerHeight - 0.5;
      pointerX = x;
      pointerY = y;
      document.documentElement.style.setProperty('--grid-x', `${x * -12}px`);
      document.documentElement.style.setProperty('--grid-y', `${y * -9}px`);
      document.documentElement.style.setProperty('--person-x', `${x * 17}px`);
      document.documentElement.style.setProperty('--person-y', `${y * 14}px`);
      const bounds = storyCard.getBoundingClientRect();
      const px = (event.clientX - bounds.left) / bounds.width;
      const py = (event.clientY - bounds.top) / bounds.height;
      if (px >= 0 && px <= 1 && py >= 0 && py <= 1) {
        storyCard.style.setProperty('--card-tilt-x', `${(0.5 - py) * 2.3}deg`);
        storyCard.style.setProperty('--card-tilt-y', `${(px - 0.5) * 2.3}deg`);
      } else {
        storyCard.style.setProperty('--card-tilt-x', '0deg');
        storyCard.style.setProperty('--card-tilt-y', '0deg');
      }
      pointerFrame = false;
    });
  }, { passive: true });
}

let touchStartX = null;
$('#story-card').addEventListener('touchstart', (event) => { touchStartX = event.changedTouches[0]?.clientX ?? null; }, { passive: true });
$('#story-card').addEventListener('touchend', (event) => {
  if (touchStartX === null) return;
  const delta = event.changedTouches[0].clientX - touchStartX;
  if (Math.abs(delta) > 42) renderSlide(currentSlide + (delta < 0 ? 1 : -1), true);
  touchStartX = null;
}, { passive: true });

// The reference-style visitor counter and notes are deliberately browser-local in this frontend-only build.
const storage = {
  get(key, fallback) { try { const value = localStorage.getItem(key); return value === null ? fallback : value; } catch { return fallback; } },
  set(key, value) { try { localStorage.setItem(key, value); return true; } catch { return false; } }
};
const COUNT_KEY = 'milo-portfolio-local-visits-v1';
const NOTES_KEY = 'milo-portfolio-local-notes-v1';
const baseVisit = 3451;
let visitNumber = baseVisit;
try {
  const prior = Number(storage.get(COUNT_KEY, String(baseVisit)));
  visitNumber = Math.max(baseVisit, Number.isFinite(prior) ? prior : baseVisit) + 1;
  storage.set(COUNT_KEY, String(visitNumber));
} catch { /* Keep the base display if browser storage is unavailable. */ }
function ordinal(n) {
  const remainder = n % 100;
  const suffix = remainder >= 11 && remainder <= 13 ? 'th' : ({ 1: 'st', 2: 'nd', 3: 'rd' }[n % 10] || 'th');
  return `${n.toLocaleString()}${suffix}`;
}
$('#visit-count').textContent = `You’re the ${ordinal(visitNumber)} visitor`;

const arrivals = [
  { who: 'A FOUNDER FROM COPENHAGEN', state: 'LOOKING' },
  { who: 'SOMEONE BUILDING IN SF', state: 'JUST HERE' },
  { who: 'A CURIOUS HUMAN', state: 'READING' },
  { who: 'AN OPERATOR FROM LONDON', state: 'LOOKING' },
  { who: 'SOMEONE WITH AN IDEA', state: 'JUST HERE' },
  { who: 'A FOUNDER FROM AMSTERDAM', state: 'READING' },
  { who: 'AN INTERNET FRIEND', state: 'LOOKING' },
  { who: 'A PERSON WITH GOOD TASTE', state: 'JUST HERE' },
  { who: 'SOMEONE PASSING THROUGH', state: 'READING' }
];
let arrivalSequence = 8;
let arrivalIndex = 0;
let seenArrivals = 8;
function renderArrivals() {
  const list = $('#arrival-list');
  const rows = arrivals.slice(arrivalIndex).concat(arrivals.slice(0, arrivalIndex)).slice(0, 4);
  list.replaceChildren();
  rows.forEach((arrival, i) => {
    const row = document.createElement('li');
    row.className = 'arrival-row';
    const time = document.createElement('span');
    time.className = 'arrival-time';
    time.textContent = i === 0 ? 'NOW' : `${i * 2 + 1}m`;
    const who = document.createElement('span');
    who.className = 'arrival-visitor';
    who.textContent = arrival.who;
    const state = document.createElement('span');
    state.className = `arrival-status${i === 0 ? ' is-new' : ''}`;
    state.textContent = i === 0 && arrivalSequence > 8 ? 'JUST IN' : arrival.state;
    row.append(time, who, state);
    list.append(row);
  });
  $('#arrival-total').textContent = `+${String(seenArrivals).padStart(2, '0')}`;
}
renderArrivals();
window.setInterval(() => {
  arrivalIndex = (arrivalIndex + 1) % arrivals.length;
  arrivalSequence++;
  if (arrivalSequence % 2 === 0) seenArrivals++;
  renderArrivals();
}, 6400);

function readNotes() {
  try {
    const parsed = JSON.parse(storage.get(NOTES_KEY, '[]'));
    return Array.isArray(parsed) ? parsed.filter((note) => note && typeof note.message === 'string').slice(0, 50) : [];
  } catch { return []; }
}
let notes = readNotes();
function updateGuestbookPreview() {
  const preview = $('#guestbook-preview');
  const count = $('#guestbook-count');
  count.textContent = `${notes.length} ${notes.length === 1 ? 'NOTE' : 'NOTES'}`;
  if (!notes.length) {
    preview.classList.remove('has-note');
    preview.replaceChildren(document.createTextNode('No notes yet.'));
    const span = document.createElement('span');
    span.textContent = 'Be the first to leave one →';
    preview.append(document.createElement('br'), span);
  } else {
    preview.classList.add('has-note');
    const latest = notes[notes.length - 1];
    preview.textContent = `“${latest.message}” — ${latest.name || 'A visitor'}`;
  }
}
updateGuestbookPreview();

const modal = $('#guestbook-modal');
const messageInput = $('#note-message');
const nameInput = $('#note-name');
const noteList = $('#notes-list');
let lastFocused = null;
function renderNotes() {
  noteList.replaceChildren();
  if (!notes.length) {
    const empty = document.createElement('p');
    empty.className = 'empty-notes';
    empty.textContent = 'The first note is always the hardest. Go on.';
    noteList.append(empty);
    return;
  }
  notes.slice().reverse().slice(0, 6).forEach((note) => {
    const entry = document.createElement('article');
    entry.className = 'note-entry';
    const head = document.createElement('div');
    head.className = 'note-entry-head';
    const name = document.createElement('span');
    name.textContent = note.name || 'A visitor';
    const time = document.createElement('time');
    time.textContent = note.when || 'just now';
    head.append(name, time);
    const body = document.createElement('p');
    body.textContent = note.message;
    entry.append(head, body);
    noteList.append(entry);
  });
}
function openGuestbook() {
  lastFocused = document.activeElement;
  renderNotes();
  modal.hidden = false;
  document.body.style.overflow = 'hidden';
  window.setTimeout(() => nameInput.focus(), 30);
}
function closeGuestbook() {
  modal.hidden = true;
  document.body.style.overflow = '';
  if (lastFocused instanceof HTMLElement) lastFocused.focus();
}
$('#open-guestbook').addEventListener('click', openGuestbook);
$('#close-guestbook').addEventListener('click', closeGuestbook);
modal.addEventListener('click', (event) => { if (event.target === modal) closeGuestbook(); });
messageInput.addEventListener('input', () => { $('#character-count').textContent = `${messageInput.value.length} / 140`; });
$('#note-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const message = messageInput.value.trim();
  if (!message) { messageInput.focus(); return; }
  const name = nameInput.value.trim().slice(0, 22);
  notes.push({ name, message: message.slice(0, 140), when: 'just now' });
  notes = notes.slice(-50);
  const saved = storage.set(NOTES_KEY, JSON.stringify(notes));
  updateGuestbookPreview();
  renderNotes();
  messageInput.value = '';
  nameInput.value = '';
  $('#character-count').textContent = '0 / 140';
  closeGuestbook();
  showToast(saved ? 'A little note, left behind.' : 'Storage is off in this browser, so the note may not stick.');
});
function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('is-visible');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('is-visible'), 2700);
}

const world = $('#world');
const drawToggle = $('#draw-toggle');
const drawToolbar = $('#draw-toolbar');
const drawCanvas = $('#draw-canvas');
const ctx = drawCanvas.getContext('2d');
let drawing = false;
let lastPoint = null;
function resizeDrawingCanvas() {
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  const old = document.createElement('canvas');
  const oldWidth = drawCanvas.width;
  const oldHeight = drawCanvas.height;
  old.width = oldWidth;
  old.height = oldHeight;
  if (oldWidth && oldHeight) old.getContext('2d').drawImage(drawCanvas, 0, 0);
  drawCanvas.width = Math.round(window.innerWidth * ratio);
  drawCanvas.height = Math.round(window.innerHeight * ratio);
  drawCanvas.style.width = `${window.innerWidth}px`;
  drawCanvas.style.height = `${window.innerHeight}px`;
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  if (oldWidth && oldHeight) ctx.drawImage(old, 0, 0, oldWidth / ratio, oldHeight / ratio, 0, 0, window.innerWidth, window.innerHeight);
  ctx.strokeStyle = '#f34452';
  ctx.lineWidth = 2;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
}
resizeDrawingCanvas();
window.addEventListener('resize', resizeDrawingCanvas, { passive: true });
function setDrawing(enabled) {
  world.classList.toggle('is-drawing', enabled);
  drawToolbar.hidden = !enabled;
  drawToggle.setAttribute('aria-pressed', String(enabled));
  drawToggle.setAttribute('aria-label', enabled ? 'Stop drawing on the wall' : 'Draw on the wall');
  if (enabled) showToast('The wall is yours. Draw anywhere.');
}
drawToggle.addEventListener('click', () => setDrawing(!world.classList.contains('is-drawing')));
$('#close-drawing').addEventListener('click', () => setDrawing(false));
$('#clear-drawing').addEventListener('click', () => ctx.clearRect(0, 0, window.innerWidth, window.innerHeight));
drawCanvas.addEventListener('pointerdown', (event) => {
  if (!world.classList.contains('is-drawing')) return;
  drawing = true;
  lastPoint = { x: event.clientX, y: event.clientY };
  drawCanvas.setPointerCapture?.(event.pointerId);
});
drawCanvas.addEventListener('pointermove', (event) => {
  if (!drawing || !lastPoint) return;
  ctx.beginPath();
  ctx.moveTo(lastPoint.x, lastPoint.y);
  ctx.lineTo(event.clientX, event.clientY);
  ctx.stroke();
  lastPoint = { x: event.clientX, y: event.clientY };
});
for (const endEvent of ['pointerup', 'pointercancel', 'lostpointercapture']) {
  drawCanvas.addEventListener(endEvent, () => { drawing = false; lastPoint = null; });
}
